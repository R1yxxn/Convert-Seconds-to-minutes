def convert_minutes_to_seconds(minutes):
    seconds = minutes * 60
    return seconds

minutes = int(input("Enter the number of minutes: "))
seconds = convert_minutes_to_seconds(minutes)
print("The equivalent seconds is:", seconds)